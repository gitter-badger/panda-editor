game.module('game.scenes')
.body(function() {

game.createScene('Main', {
    init: function() {
        for (var i = 0; i < 10; i++) {
            var panda = new game.Panda();
        }
        for (var i = 0; i < 5; i++) {
            var panda = new game.BigPanda();
        }
    }
});

});
