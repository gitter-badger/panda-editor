game.module('game.objects')
.body(function() {

game.createClass('Panda', {
    minSpeed: 100,
    maxSpeed: 200,
    scale: 1,
    
    init: function() {
        this.sprite = new game.Sprite('panda');
        this.sprite.anchor.set(0.5, 0.5);
        this.sprite.scale.set(this.scale);
        this.sprite.position.x = Math.random() * game.system.width;
        this.sprite.position.y = Math.random() * game.system.height;
        this.sprite.addTo(game.scene.stage);
        
        this.changeSpeed();
        
        
        
        game.scene.addObject(this);
    },
    
    changeSpeed: function() {
        this.speed = Math.random(this.minSpeed, this.maxSpeed);
    },
    
    update: function() {
        this.sprite.position.y -= this.speed * game.system.delta;
        this.sprite.rotation += this.speed / 100 * game.system.delta;
        
        if (this.sprite.position.y + this.sprite.height / 2 < 0) {
            this.sprite.position.y = game.system.height + this.sprite.height / 2;
            this.changeSpeed();
        }
    }
});

game.createClass('BigPanda', 'Panda', {
    minSpeed: 300,
    maxSpeed: 400,
    scale: 2
});

});
