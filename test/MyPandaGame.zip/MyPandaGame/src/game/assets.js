game.module('game.assets')
.body(function() {

game.addAsset('panda.png', 'panda');

});
