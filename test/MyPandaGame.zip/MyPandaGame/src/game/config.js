pandaConfig = {
    "name": "MyPandaGame",
    "version": "0.1.0",
    "system": {
        "center": true,
        "scale": true,
        "resize": false,
        "width": 768,
        "height": 1024,
        "startScene": "Main",
        "rotateScreen": false
    },
    "debug": {
        "enabled": true
    }
};