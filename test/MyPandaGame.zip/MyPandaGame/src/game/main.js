game.module('game.main')
.require('game.assets', 'game.objects', 'game.scenes')
.body(function() {

});
